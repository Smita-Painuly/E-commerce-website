let card=document.querySelector(".trends");
let card2=document.querySelector(".womens");
let blog=document.querySelector(".trend");
let about=document.querySelector(".about");
let contact=document.querySelector(".contact");
let mainpage=document.querySelector(".main");

// home
function homes(){
mainpage.style.display="flex";
card.style.display="block";
card2.style.display="block";
blog.style.display="block";
shops.style.display="block"

}

document.getElementById("shop").style.color="black";
document.getElementById("home").style.color="rgb(6, 175, 175)";
document.getElementById("blog").style.color="black";
document.getElementById("contact").style.color="black";
document.getElementById("about").style.color="black";

// shop
function shops(){
mainpage.style.display="none";
blog.style.display="none";
about.style.display="none";
contact.style.display="none";


document.getElementById("shop").style.color="rgb(6, 175, 175)";
document.getElementById("home").style.color="black";
document.getElementById("blog").style.color="black";
document.getElementById("contact").style.color="black";
document.getElementById("about").style.color="black";
}

// blog
function blogs(){
 mainpage.style.display="none";
 card.style.display="none";
 card2.style.display="none";
blog.style.display="block";
contact.style.display="none";
about.style.display="none";


document.getElementById("blog").style.color="rgb(6, 175, 175)";
document.getElementById("home").style.color="black";
document.getElementById("shop").style.color="black";
document.getElementById("contact").style.color="black";
document.getElementById("about").style.color="black";
}

// about
function abouts(){
    mainpage.style.display="none";
    card.style.display="none";
    card2.style.display="none";
   blog.style.display="none";
   about.style.display="block";
contact.style.display="none";

   
   document.getElementById("blog").style.color="black";
   document.getElementById("home").style.color="black";
   document.getElementById("shop").style.color="black";
   document.getElementById("about").style.color="rgb(6, 175, 175)";
   document.getElementById("contact").style.color="black";
}

// contact
function contacts(){
    mainpage.style.display="none";
    card.style.display="none";
    card2.style.display="none";
   blog.style.display="none";
   about.style.display="none";
   contact.style.display="block";
   
   document.getElementById("blog").style.color="black";
   document.getElementById("home").style.color="black";
   document.getElementById("shop").style.color="black";
   document.getElementById("about").style.color="black";
   document.getElementById("contact").style.color="rgb(6, 175, 175)"
}

function show(img){
   let newImg=document.getElementById("newImg");
   newImg.src=img.src;

   document.querySelector(".cart").style.display="flex";
   mainpage.style.display="none";
    card.style.display="none";
    card2.style.display="none";
   blog.style.display="none";
   about.style.display="none";
   contact.style.display="none";
}

function addCart(){
   alert("Added To Cart");
   location.reload;
}